# lab8_php_koneksidatabase
Koneksi Database dengan PHP - Lab8 Pemograman Web 

Rangga Tito Prayogo - TI 19 B1
#

Membuat Database
![image](https://user-images.githubusercontent.com/46300525/120113366-5a607400-c1a4-11eb-8313-b0f3a322fc3b.png)

Koneksi Mysql dengan PHP
![image](https://user-images.githubusercontent.com/46300525/120140601-12be0480-c205-11eb-9ca1-43ab49c8775b.png)
![image](https://user-images.githubusercontent.com/46300525/120140687-3e40ef00-c205-11eb-8748-3112cd894c7d.png)


Menambahkan Data
![image](https://user-images.githubusercontent.com/46300525/120140792-7ba57c80-c205-11eb-853f-b741d9a7417a.png)
![image](https://user-images.githubusercontent.com/46300525/120140844-95df5a80-c205-11eb-9c9b-abc4dd2b93e1.png)
![image](https://user-images.githubusercontent.com/46300525/120140878-a55ea380-c205-11eb-8efb-2defa611efa6.png)

Mengedit Data
![image](https://user-images.githubusercontent.com/46300525/120141005-db038c80-c205-11eb-9463-a2191accd883.png)
![image](https://user-images.githubusercontent.com/46300525/120141052-efe02000-c205-11eb-94bd-1dfc1585f753.png)
![image](https://user-images.githubusercontent.com/46300525/120141132-1bfba100-c206-11eb-94e6-f296e6895c28.png)

Menghapus Barang
![image](https://user-images.githubusercontent.com/46300525/120141192-3d5c8d00-c206-11eb-8c65-652a61b956a8.png)
![image](https://user-images.githubusercontent.com/46300525/120141374-90364480-c206-11eb-9961-7d7944f84cd8.png)
![image](https://user-images.githubusercontent.com/46300525/120141396-99271600-c206-11eb-83c0-dc0f98ea4000.png)
![image](https://user-images.githubusercontent.com/46300525/120141474-c4116a00-c206-11eb-976c-a6a720794014.png)

Terimakasih pak






